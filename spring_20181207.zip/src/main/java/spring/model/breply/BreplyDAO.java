package spring.model.breply;

public class BreplyDAO {

}
