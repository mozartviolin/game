package spring.model.survey;

import spring.model.stdinter.DAOSTDInter;

public interface ISurveyDAO extends DAOSTDInter {

}
