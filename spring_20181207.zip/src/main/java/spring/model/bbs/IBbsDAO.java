package spring.model.bbs;

import spring.model.stdinter.DAOSTDInter;

public interface IBbsDAO extends DAOSTDInter {

}
