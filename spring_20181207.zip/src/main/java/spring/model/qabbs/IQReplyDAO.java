package spring.model.qabbs;

import spring.model.stdinter.DAOSTDInter;

public interface IQReplyDAO extends DAOSTDInter {

}
