package spring.model.qabbs;

import spring.model.stdinter.DAOSTDInter;

public interface IQabbsDAO extends DAOSTDInter {

}
