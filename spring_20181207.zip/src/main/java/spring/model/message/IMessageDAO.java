package spring.model.message;

import spring.model.stdinter.DAOSTDInter;

public interface IMessageDAO extends DAOSTDInter {

}
