package spring.model.notice;

import spring.model.stdinter.DAOSTDInter;

public interface INoticeDAO extends DAOSTDInter {

}
