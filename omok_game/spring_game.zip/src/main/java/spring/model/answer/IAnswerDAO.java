package spring.model.answer;

import spring.model.stdinter.DAOSTDInter;

public interface IAnswerDAO extends DAOSTDInter {

}
